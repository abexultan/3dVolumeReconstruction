.. cilantro documentation master file, created by
   sphinx-quickstart on Sat May  5 14:48:48 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

========
cilantro
========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   about
   getting_started


.. Indices and tables
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`
